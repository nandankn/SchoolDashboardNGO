Important Notes:

1. Update input excel sheet in the input folder with filter data.
2. Update JSON file path in web.config under publish folder(The bot will put the json file in outputs folder)
3. Once the BOT completes its execution, the user can interact with the dashboard for more informative school information.
